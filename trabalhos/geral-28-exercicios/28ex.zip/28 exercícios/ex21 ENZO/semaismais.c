#include <stdio.h>

int main() {
    int x, y;
    printf("Printe dois numeros para soma:  \n\n");
    scanf("%d", &x);
    scanf("%d", &y);



    printf("A soma �: %d%d", x, y);
}
